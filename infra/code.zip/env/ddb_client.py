import boto3
import os

# Global variable to hold the DynamoDB client instance
__ddb_client = None

# Get the environment variable 'ENV', default to 'dev' if not set
env = os.getenv("ENV", "dev")

def setup_dynamodb_client():
    """
    Set up the DynamoDB client based on the environment.

    If the environment is 'local', configure the client to connect to a local
    DynamoDB instance with dummy credentials. Otherwise, use the default
    configuration.

    This function initializes the global __ddb_client variable.
    """
    global __ddb_client

    params = {}

    if env == "local":
        params = {
            "endpoint_url": "http://localhost:8000", # docker
            "region_name": "dummy",
            "aws_access_key_id": "dummy",
            "aws_secret_access_key": "dummy"
        }

    __ddb_client = boto3.resource(
        "dynamodb",
        **params
    ) 


def get_ddb_client():
    """
    Get the DynamoDB client instance.

    If the client has not been initialized, set it up first.

    Returns:
        boto3.resources.factory.dynamodb.ServiceResource: The DynamoDB client instance.
    """
    if not __ddb_client:
        setup_dynamodb_client()

    return __ddb_client